INSTRUCCIONES
-------------
Este paquete incluye un sitio estático (index.html) y una carpeta 'images/' con 5 ilustraciones SVG creadas y embebidas localmente.

Archivos incluidos:
- index.html
- /images/hero.svg
- /images/definicion.svg
- /images/importancia.svg
- /images/ejemplos.svg
- /images/conclusion.svg

Las ilustraciones son SVGs estilizadas (vectoriales) y pueden abrirse con cualquier navegador o editor de imágenes. Si prefieres reemplazarlas por fotografías, puedes sustituir los archivos dentro de la carpeta images/ conservando los mismos nombres.

Cómo usar:
1) Descarga y extrae el ZIP.
2) Abre index.html en tu navegador (doble clic).
3) Si deseas cambiar imágenes, remplaza los archivos en /images/ por fotos (.jpg/.png) con los mismos nombres.

Créditos: Ilustraciones generadas y empaquetadas aquí para uso libre por tu proyecto.
